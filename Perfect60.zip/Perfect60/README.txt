1) Install Cornerstone font - http://befonts.com/cornerstone-font.html

2) Open "Perfect60"

3) Click "OBS" (in the bottom left)

4) In OBS, or any streaming software, add new Window Capture for the "Perf60 OBS" window. Uncheck "Capture Cursor"

5) Right click new Window Capture, select Filter

6) Add new filter (in the bottom left), select Chroma Key

7) Set Key Color Type to "Magenta." Set Similarity to 300. Default on the rest is great.

8) Scale the window in OBS to however large you like

9) Click "New Run" in the app. Keep track of wins/losses by clicking "Win" or "Loss." If you ever want to retire your run, you can hit "Reset" then "New Run" to start from the top.

enjoy, and thanks for checking out my Hearthstone Perfect60 application.

Matt~